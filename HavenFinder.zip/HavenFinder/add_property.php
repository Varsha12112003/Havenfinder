<?php
// Database configuration
$servername = "localhost";
$username = "root"; // Default username for WAMP
$password = "KalaiVani141225"; // Default password for WAMP (empty)
$dbname = "havenfinder";

// Establish database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form data is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $purpose = $_POST['purpose'];
    $address = $_POST['address'];
    $zip = $_POST['zip'];
    $bedrooms = $_POST['bedrooms'];
    $bathrooms = $_POST['bathrooms'];
    $area = $_POST['area'];
    $parking = $_POST['parking'];
    $price = $_POST['price'];
    $negotiable = $_POST['negotiable'];

    // SQL query to insert data
    $sql = "INSERT INTO properties (title, purpose, address, zip, bedrooms, bathrooms, area, parking, price, negotiable) 
            VALUES ('$title', '$purpose', '$address', '$zip', $bedrooms, $bathrooms, '$area', '$parking', $price, '$negotiable')";

    if ($conn->query($sql) === TRUE) {
        // Redirect to index.html after success
        header("Location: index.html");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the connection
$conn->close();
?>
