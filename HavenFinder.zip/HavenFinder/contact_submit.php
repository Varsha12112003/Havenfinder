<?php
// Database credentials
$host = 'localhost';
$username = 'root';
$password = 'KalaiVani141225'; // Default WAMP password
$database = 'havenfinder';

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstName = $_POST['contact-first-name'];
    $lastName = $_POST['contact-last-name'];
    $email = $_POST['contact-email'];
    $phone = $_POST['contact-phone'];
    $subject = $_POST['contact-subject'];
    $message = $_POST['contact-message'];

    // Insert data into the database
    $stmt = $conn->prepare("INSERT INTO contact_submissions (first_name, last_name, email, phone, subject, message) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $firstName, $lastName, $email, $phone, $subject, $message);

    if ($stmt->execute()) {
        echo "<script>
            alert('Your message has been sent successfully! 😊');
            window.location.href = 'contact.html';
        </script>";
    } else {
        echo "<script>
            alert('Failed to send your message. Please try again.');
            window.location.href = 'contact.html';
        </script>";
    }

    $stmt->close();
    $conn->close();
}
?>
