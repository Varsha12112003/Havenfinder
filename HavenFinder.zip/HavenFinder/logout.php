<?php
session_start();
session_destroy();
header("Location: index.html"); // Redirect to homepage or login page
exit();
?>
